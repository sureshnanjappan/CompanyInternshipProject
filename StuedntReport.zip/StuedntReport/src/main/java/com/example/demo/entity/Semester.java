package com.example.demo.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity

public class Semester {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int semesterNo;

	
@JsonIgnore
	
	@OneToMany(mappedBy = "semester1")

	private Set<Subject>subject=new HashSet<>();

	public Set<Subject> getSubject() {
	return subject;
}

public void setSubject(Set<Subject> subject) {
	this.subject = subject;
}

	public int getSemesterNo() {
		return semesterNo;
	}

	public void setSemesterNo(int semesterNo) {
		this.semesterNo = semesterNo;
	}

	

}
