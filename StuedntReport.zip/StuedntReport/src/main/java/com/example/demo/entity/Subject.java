package com.example.demo.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotEmpty;

@Entity

public class Subject {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int subjectId;
	private String subjectName;
	
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(
			name="student_enrolled", joinColumns = @JoinColumn(name="subject_id"),
	
	        inverseJoinColumns = @JoinColumn(name="student_id"))
			
			Set<Student>enrolledstudent=new HashSet<>();
	
	
	public Set<Student> getEnrolledstudent() {
		return enrolledstudent;
	}
	public void setEnrolledstudent(Set<Student> enrolledstudent) {
		this.enrolledstudent = enrolledstudent;
	}
@ManyToOne(cascade = CascadeType.ALL)
	
	@JoinColumn(name="semester",referencedColumnName = "semesterNo")
	
	private Semester semester1;
	
	public Semester getSemester1() {
	return semester1;
}
public void setSemester1(Semester semester1) {
	this.semester1 = semester1;
}
	public int getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public void enrollStudent(Student student) {
		enrolledstudent.add(student);
		
	}
	public void enrollToSemester(Semester semester) {
		this.semester1=semester;
		
	}

	
	
	

}
