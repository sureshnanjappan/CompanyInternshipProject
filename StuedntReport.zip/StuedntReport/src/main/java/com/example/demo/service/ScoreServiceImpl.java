package com.example.demo.service;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Score;
import com.example.demo.entity.Student;
import com.example.demo.entity.Subject;
import com.example.demo.error.NotFoundException;
import com.example.demo.repository.ScoreRepository;
import com.example.demo.repository.StudentRepository;

@Service

public class ScoreServiceImpl implements ScoreService {
	@Autowired
	 private ScoreRepository scorerepository;
@Autowired 
private StudentRepository studentrepository;
	
	
	@Override
	public Score addScore(@Valid Score score) {
		// TODO Auto-generated method stub
		return scorerepository.save(score);
	}

	@Override
	public Score assignScoreToStudent(Integer scoreid, Integer stuid) throws NotFoundException, NotFoundException  {
		Optional<Score>score1=scorerepository.findById(scoreid);
		if(!score1.isPresent())
			throw new NotFoundException("subject not found");
		
		Optional<Student>student1=studentrepository.findById(stuid);
		if(!student1.isPresent())
			throw new NotFoundException("student not found");
		
		else {
			//Subject subject2=subjectrepository.findById(scoreid).get();
		
		Score score =scorerepository.findById(scoreid).get();
		Student student= studentrepository.findById(stuid).get();
		Score.enrollToSemester(student);
		
		
		return scorerepository.save(score);
	}
	}



}
