package com.example.demo.service;

import javax.validation.Valid;

import com.example.demo.entity.Semester;

public interface SemesterService {

	Semester addSemester(@Valid Semester semester);

}
