package com.example.demo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Score;
import com.example.demo.entity.Subject;
import com.example.demo.error.NotFoundException;
import com.example.demo.repository.ScoreRepository;
import com.example.demo.service.ScoreService;

@RestController

public class ScoreController {
	@Autowired
	ScoreService scoreservice;
	@Autowired
	ScoreRepository scorerepository;
	
	@PostMapping("/score")
	public ResponseEntity<Score> addScore(@Valid @RequestBody Score score) {
	
	Score score1=scoreservice.addScore(score);	
		return new ResponseEntity<>(score1,HttpStatus.CREATED);
	}
	@PutMapping("/score/{scoreid}/student/{stuid}")
	public Score assignScoreToStudent(@PathVariable("scoreid")Integer scoreid,@PathVariable("stuid")Integer stuid) throws NotFoundException, NotFoundException {
		return scoreservice.assignScoreToStudent(scoreid,stuid);
	}
	@GetMapping("/totalscore")
	 public float studenttotalscore() {
		 return scorerepository.totalScore();
	 }
	
	@GetMapping("/countscore")
	 public float scorecount() {
		 return scorerepository.countScore();
	 }
	

	@GetMapping("/pofstudents")
	public String profitAndLoss() {
		float pf=scorerepository.totalScore()/scorerepository.countScore();
		if(pf>0)
		return "score"+pf;
		else
			return "error";
	}
	

}
