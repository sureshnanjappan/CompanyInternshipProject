package com.example.demo.service;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Semester;
import com.example.demo.repository.SemesterRepository;
@Service

public class SemesterServiceImpl implements SemesterService {
	@Autowired
	private SemesterRepository semesterrepository;

	@Override
	public Semester addSemester(@Valid Semester semester) {
		
		return semesterrepository.save(semester);
	}

	
	

}
