package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Semester;
import com.example.demo.entity.Student;
import com.example.demo.entity.Subject;
import com.example.demo.error.NotFoundException;
import com.example.demo.repository.SemesterRepository;
import com.example.demo.repository.StudentRepository;
import com.example.demo.repository.SubjectRepository;

@Service

public class SubjectServiceImpl implements SubjectService{
	
	@Autowired
	private SubjectRepository subjectrepository;

	@Autowired
	private StudentRepository studentrepository;
	@Autowired
	private SemesterRepository semesterrepository;
	
	@Override
	public Subject addSubject(@Valid Subject subject) {
		// TODO Auto-generated method stub
		return subjectrepository.save(subject) ;
	}

	@Override
	public List<Subject> getAllSubject() {
		// TODO Auto-generated method stub
		return subjectrepository.findAll();
	}

	@Override
	public Subject enrolledStudentsToSubject(Integer subid, Integer stuid) throws NotFoundException, NotFoundException {
		
		
		
		Optional<Subject>subject1=subjectrepository.findById(subid);
		if(!subject1.isPresent())
			throw new NotFoundException("subject not found");
		
		Optional<Student>student1=studentrepository.findById(stuid);
		if(!subject1.isPresent())
			throw new NotFoundException("student not found");
		
		else {
			//Subject subject2=subjectrepository.findById(subid).get();
		
		Subject subject =subjectrepository.findById(subid).get();
		Student student= studentrepository.findById(stuid).get();
		subject.enrollStudent(student);
		
		
		return subjectrepository.save(subject) ;
	}
	}

	@Override
	public Subject enrolledSubjectToSemester(Integer subid, Integer semesterno)throws NotFoundException, NotFoundException {

		Optional<Subject>subject1=subjectrepository.findById(subid);
		if(!subject1.isPresent())
			throw new NotFoundException("subject not found");
		
		Optional<Semester>semester1=semesterrepository.findById(semesterno);
		if(!subject1.isPresent())
			throw new NotFoundException("semester not found");
		
		else {
			//Subject subject2=subjectrepository.findById(subid).get();
		
		Subject subject =subjectrepository.findById(subid).get();
		Semester semester= semesterrepository.findById(semesterno).get();
		subject.enrollToSemester(semester);
		
		
		return subjectrepository.save(subject) ;
	}
	}

	

	
	
	
}
