package com.example.demo.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity

public class Score {
	@Id
	private int scoreGained;
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(
			name="score_details", joinColumns = @JoinColumn(name="score"),
	
	        inverseJoinColumns = @JoinColumn(name="student_id"))
			
			static Set<Student>studentscore=new HashSet<>();

	public Set<Student> getEnrolledstudent() {

		return studentscore;
	}

	public void setEnrolledstudent(Set<Student> enrolledstudent) {
		this.studentscore = enrolledstudent;
	}

	public int getScoreGained() {
		return scoreGained;
	}

	public void setScoreGained(int scoreGained) {
		this.scoreGained = scoreGained;
	}

	public static  void enrollToSemester(Student student) {
		studentscore.add(student);
		
	}

	

	
	
}
