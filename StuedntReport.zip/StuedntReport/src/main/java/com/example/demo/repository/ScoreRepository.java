package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Score;

@Repository

public interface ScoreRepository extends JpaRepository<Score,Integer>{
	
	@Query("select sum(m.scoreGained) from Score m")
	float totalScore();

	
	
	@Query("select count(n.scoreGained) from Score n")
	float countScore();

}
