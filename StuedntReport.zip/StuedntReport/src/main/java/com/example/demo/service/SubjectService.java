package com.example.demo.service;

import java.util.List;

import javax.validation.Valid;

import com.example.demo.entity.Subject;
import com.example.demo.error.NotFoundException;


public interface SubjectService {

	Subject addSubject(@Valid Subject subject);

	List<Subject> getAllSubject();

	Subject enrolledStudentsToSubject(Integer subid, Integer stuid) throws NotFoundException, NotFoundException;

	Subject enrolledSubjectToSemester(Integer subid, Integer semesterno) throws NotFoundException, NotFoundException;

	

}
