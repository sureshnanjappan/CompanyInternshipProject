package com.example.demo.service;

import java.util.List;

import javax.validation.Valid;

import com.example.demo.entity.Student;
import com.example.demo.error.NotFoundException;

public interface StudentService {

	Student addStudent(@Valid Student student);

	List<Student> getAllStudents();

	

	

}
