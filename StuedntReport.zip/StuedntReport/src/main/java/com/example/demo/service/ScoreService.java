package com.example.demo.service;

import javax.validation.Valid;

import com.example.demo.entity.Score;
import com.example.demo.entity.Subject;
import com.example.demo.error.NotFoundException;

public interface ScoreService {

	Score addScore(@Valid Score score);

	Score assignScoreToStudent(Integer scoreid, Integer stuid) throws NotFoundException, NotFoundException;

}
